export function Button({ children, className, variant, ...props }) {
  const base='px-4 py-2 rounded-md font-semibold transition';
  const variantStyle = variant==='outline'?'border border-gray-500 bg-transparent':'bg-white text-black';
  return <button className={`${base} ${variantStyle} ${className}`} {...props}>{children}</button>;
}