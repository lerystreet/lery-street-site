import { Card, CardContent } from './ui/Card';
import { Button } from './ui/Button';
import { ShoppingBag, MessageCircle } from 'lucide-react';
import { motion } from 'framer-motion';

export default function LeryStreet() {
  const produtos = [
    { nome: 'Camiseta Oversized', preco: 'R$ 99,90' },
    { nome: 'Calça Cargo Street', preco: 'R$ 219,90' },
    { nome: 'Moletom Urban', preco: 'R$ 259,90' }
  ];
  return (
    <div className='min-h-screen bg-neutral-950 text-neutral-100 p-6'>
      <header className='flex items-center justify-between mb-12'>
        <h1 className='text-4xl font-extrabold tracking-widest'>LERY STREET</h1>
        <div className='flex gap-3'>
          <Button variant='outline'><MessageCircle size={18} /> WhatsApp</Button>
          <Button className='flex gap-2 bg-white text-black'><ShoppingBag size={18} /> Carrinho</Button>
        </div>
      </header>
      <motion.section initial={{opacity:0,y:30}} animate={{opacity:1,y:0}} className='grid grid-cols-1 md:grid-cols-3 gap-6'>
        {produtos.map((p,i)=>(
          <Card key={i} className='rounded-2xl bg-neutral-900 border-neutral-800'>
            <CardContent className='p-4 flex flex-col gap-3'>
              <div className='h-44 bg-neutral-800 rounded-xl' />
              <h2 className='text-lg font-semibold uppercase'>{p.nome}</h2>
              <p className='text-neutral-400'>{p.preco}</p>
              <Button className='bg-white text-black'>Comprar</Button>
            </CardContent>
          </Card>
        ))}
      </motion.section>
      <section className='mt-20 text-center'>
        <h2 className='text-2xl font-bold mb-3'>Streetwear pra quem vive a rua</h2>
        <p className='text-neutral-400 max-w-xl mx-auto'>
          Moda urbana, jovem e autêntica. Vista a atitude da Lery Street — online, na vitrine ou direto no WhatsApp.
        </p>
      </section>
      <footer className='mt-24 text-center text-sm text-neutral-500'>© 2026 LERY STREET. Todos os direitos reservados.</footer>
    </div>
  );
}