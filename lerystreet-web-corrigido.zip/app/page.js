import LeryStreet from '../components/LeryStreet';
export default function Page() { return <LeryStreet />; }